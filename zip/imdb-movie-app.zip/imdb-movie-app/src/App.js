import './App.css';
import Card from './components/Card';
import Search from './components/Search';

function App() {
    return (
        <div>
            <center>
                <Search />
                <Card />
                <Card />
                <Card />
                <Card />
                <Card />
                <Card />
            </center>
        </div>
    );
}

export default App;